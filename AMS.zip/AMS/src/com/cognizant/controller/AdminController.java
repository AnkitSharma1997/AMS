package com.cognizant.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Manager;
import com.cognizant.model.AdminModel;
import com.cognizant.service.AdminService;
import java.util.*;

import javax.servlet.http.HttpSession;


@Controller
public class AdminController {
	@Autowired
	private AdminService adminService;
	
	@Autowired
	@Qualifier("adminLoginValidator")
	private Validator loginValidator;
	
	@Autowired
	@Qualifier("adminRegistrationValidator")
	private Validator registerValidator;

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);
	
	@RequestMapping(value ="main.htm")
	public String main(){
		logger.info("Loading Main Page");
		return "main";
	}

	@RequestMapping(value="adminRegister.htm")
	public String loadRegisterAdmin(){
		logger.info("Loading Admin Registration Page");
		return "adminRegister";
	}
	
	@RequestMapping(value ="adminRegisterSuccess.htm", method = RequestMethod.POST)
	public ModelAndView registerAdmin(@ModelAttribute("adminModel")AdminModel adminModel,Errors errors){
		logger.info("Admin Registration Page Submitted");
		ModelAndView mv = new ModelAndView();
		
		ValidationUtils.invokeValidator(registerValidator, adminModel , errors);
		if(errors.hasErrors())
		{
			logger.info("Admin Registration Failed");
			mv.setViewName("adminRegister");
		}
		else
		{
		boolean persistAdmin=adminService.registerAdmin(adminModel);
		if(persistAdmin)
		{
			logger.info("Admin Registration Successfully");
			String Id=adminService.getId();
			mv.addObject("status","Admin Registered");
			mv.addObject("adminMSG", adminModel.getAdminFirstName()+adminModel.getAdminLastName()+" can Login using =>");
			mv.addObject("note", "Admin Id : ");
			mv.addObject("adminId", Id);
		}
		else{
			logger.info("Admin Registration Failed");
			mv.addObject("status","Admin Registration Failed");
		}
		}
		mv.setViewName("adminRegister");
		return mv;
	}
	
	@RequestMapping(value="adminLogin.htm")
	public String loadAdminLogin(){
		logger.info("Loading Admin Login Page");
		return "adminLogin";
	}
	
	@RequestMapping(value="adminLoginSuccess.htm",method=RequestMethod.POST)
	public ModelAndView adminLogin(@ModelAttribute("adminModel") AdminModel adminModel,Errors errors,HttpSession session)
	{
		logger.info("Admin Login Page Submitted");
		ModelAndView mv=new ModelAndView();
		ValidationUtils.invokeValidator(loginValidator, adminModel , errors);
		if(errors.hasErrors())
		{
			logger.info("Admin Login Failed");
			mv.setViewName("adminLogin");
		}
		else
		{
		int checkAdmin=adminService.checkAdminLogin(adminModel);
		if(checkAdmin==4)
		{
			logger.info("Admin Login Successful");
			mv.addObject("status","Admin Login Successful");
			mv.addObject("adminId", adminModel.getAdminId());
			mv.addObject("adminName", adminModel.getAdminFirstName());
			session.setAttribute("adminId",adminModel.getAdminId());
			session.setAttribute("adminName",adminModel.getAdminFirstName());
			mv.setViewName("welcomeAdmin");
		}
		else
		{
			logger.info("Admin Login Failed");
			mv.addObject("status","Admin Login Failed");
			mv.setViewName("adminLogin");
		}
		}
		return mv;
	}
	
	@RequestMapping(value="adminLogout.htm",method=RequestMethod.GET)
	public ModelAndView logout (HttpSession session){
		ModelAndView mv = new ModelAndView();
		session.invalidate();
		logger.info("Admin Logout Successful");
		mv.setViewName("main");
		return mv;
	}
	
	@RequestMapping(value="welcomeAdmin.htm")
	public String loadAdminWelcome(){
		logger.info("Loading Admin Welcome Page");
		return "welcomeAdmin";
	}
	
	@RequestMapping(value="managerPendingRequests.htm",method=RequestMethod.GET)
	public ModelAndView getAllManagerrequests()
	{
		
		ModelAndView mv=new ModelAndView();
	
		//	System.out.println("Controller");
		
		List<Manager> managerPendingRequests=adminService.getAllPendingRequests();
		mv.addObject("managerList",managerPendingRequests);
		
		//System.out.println(managerPendingRequests);
		//int pendingRequests=NotificationService.pendingRequestsCount;
		//mv.addObject("pendingCount",pendingRequests);
		
		mv.setViewName("managerRequest");
		return mv;
	}

	@RequestMapping(value="changeRequestStatus.htm")
	public ModelAndView changeRequestStatus(@RequestParam("managerId")String managerId,@RequestParam("action")String action){
		ModelAndView mv=new ModelAndView();
		
		if(action.equals("approve"))
		{
			//System.out.println("action");
			boolean approveStatus=adminService.approveManagerRequest(managerId);
			
			if(approveStatus)
				mv.addObject("status","Approved");
		} else
		{
			//System.out.println("action");
			boolean rejectStatus=adminService.rejectManagerRequest(managerId);
			//System.out.println(rejectStatus);
			if(rejectStatus)
				mv.addObject("status","Rejected");
		}
		List <Manager> managerPendingRequests=adminService.getAllPendingRequests();
		mv.addObject("managerList",managerPendingRequests);
		
		//int pendingRequests=NotificationService.pendingRequestsCount;
		//mv.addObject("pendingCount",pendingRequests);
		
		mv.setViewName("managerRequest");
		return mv;
	}

	@ModelAttribute("adminModel")
	public AdminModel createAdminObject(){
		AdminModel adminModel = new AdminModel();
		return adminModel;
	}
	
	@ModelAttribute("genderList")
	public List<String> createGenderList(){
		return adminService.getGender();
	}
}