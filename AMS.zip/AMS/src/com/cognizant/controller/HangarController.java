package com.cognizant.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Hangar;
import com.cognizant.entity.HangarStatus;
import com.cognizant.model.HangarModel;
import com.cognizant.model.HangarStatusModel;
import com.cognizant.service.HangarService;
import com.cognizant.service.PlaneService;

@Controller
@SessionAttributes({ "view1HangarModel", "hangarId", "managerId" })
public class HangarController {

	@Autowired
	private HangarService hangarService;

	@Autowired
	private PlaneService planeService;

	@Autowired
	@Qualifier("hangarValidator")
	private Validator validator;

	private static  Logger logger = LoggerFactory.getLogger(HangarController.class);

	@RequestMapping(value = "hangarMain.htm", method = RequestMethod.GET)
	public String loadHangarMain() {
		logger.info("Loading Hangar Main Page");
		return "hangarMain";
	}

	@RequestMapping(value = "hangarForm.htm", method = RequestMethod.GET)
	public String loadHangarForm() {
		logger.info("Loading Add Hangar Form");
		return "hangarForm";
	}

	@RequestMapping(value = "addHangar.htm", method = RequestMethod.POST)
	public ModelAndView persistHangar(@ModelAttribute("hangarModel") HangarModel hangarModel, Errors errors) {

		ModelAndView mv = new ModelAndView();
		logger.info("Add Hangar Form Submitted");

		ValidationUtils.invokeValidator(validator, hangarModel, errors);
		if (errors.hasErrors()) {
			logger.info("Addition of Hangar Failed");
			mv.setViewName("hangarForm");
		} else {
			boolean hangarPersist = hangarService.persistHangar(hangarModel);
			if (hangarPersist) {
				logger.info("Addition of Hangar Successful");
				mv.addObject("status", "Your details are submitted successfully");
			} else {
				logger.info("Addition of Hangar Failed");
				mv.addObject("status", "Please update the highlighted mandatory field(s)");
			}
		}
		
		hangarService.getHangarIdManagerId();
	
		mv.setViewName("hangarForm");
		return mv;
	}

	@RequestMapping(value = "viewHangars.htm", method = RequestMethod.GET)
	public ModelAndView viewHangars() {
		logger.info("View All Hangars");
		List<Hangar> hangarList = hangarService.getAllHangars();
		ModelAndView mv = new ModelAndView();
		mv.addObject("hangarList", hangarList);
		mv.setViewName("viewHangars");
		return mv;
	}

	@RequestMapping(value = "viewOneHangar.htm", method = RequestMethod.GET)
	public ModelAndView viewHangar(ModelMap map, @ModelAttribute("hangarmodel") HangarModel hangarModel,
			@RequestParam("hangarId") int hangar1) {
		logger.info("View One Hangar Details");
		ModelAndView mv = new ModelAndView();
		HangarModel view1HangarModel = hangarService.getHangar(hangar1);
		map.addAttribute("view1HangarModel", view1HangarModel);
		mv.setViewName("viewOneHangar");
		return mv;
	}

	@RequestMapping(value = "editHangar.htm", method = RequestMethod.POST)
	public ModelAndView updateHangar(@ModelAttribute("view1HangarModel") HangarModel hangarModel, Errors errors) {
		logger.info("Update Hangar Form Submitted");

		ModelAndView mv = new ModelAndView();
		ValidationUtils.invokeValidator(validator, hangarModel, errors);
		if (errors.hasErrors()) {
			logger.info("Updation of Hangar Failed");
			mv.setViewName("hangarForm");
		} else {
			boolean hangarUpdate = hangarService.updateHangar(hangarModel);
			if (hangarUpdate) {
				logger.info("Updation of Hangar Successful");
				mv.addObject("status", "Your details are submitted successfully");
			} else {
				logger.info("Updation of Hangar Failed");
				mv.addObject("status", "Hangar registration failed, TRY Again");
			}
		}
		mv.setViewName("viewOneHangar");
		return mv;
	}

	@RequestMapping(value="hangarAllocation.htm",method=RequestMethod.GET)
	public ModelAndView setAllocationView()
	{
		logger.info("View All Hangar Status");
		List<HangarStatus> hangarStatusList = hangarService.getAllHangarStatus();
		ModelAndView mv = new ModelAndView();
		mv.addObject("hangarStatusList", hangarStatusList);
		mv.setViewName("viewHangerAllocation");
		return mv;
	}

	@RequestMapping(value="allocatePlaneForm.htm",method=RequestMethod.GET)
	public ModelAndView viewAllocationForm(ModelMap map,@RequestParam("hangarId")int hangarId,@RequestParam("managerId")String managerId){
		
		ModelAndView mv = new ModelAndView();
		System.out.println(hangarId);
		System.out.println(managerId);
		List<Number> planeIdList =planeService.getAllPlaneId();
		for(Number i:planeIdList)
		{	
			System.out.println(i);
		}		
		mv.addObject("planeIdList",planeIdList);
	    map.addAttribute("hangarId",hangarId);
		map.addAttribute("managerId",managerId);
		mv.setViewName("hangarAllocationForm");		
		return mv;
	}
	
	@RequestMapping(value="addPlaneIntoHanger.htm",method=RequestMethod.POST)
	public ModelAndView allocatePlaneMethod(@ModelAttribute("hangarStatusModel")HangarStatusModel hangarStatusModel){
		ModelAndView mv = new ModelAndView();
		
		String status="allocated successfully";
		
		//System.out.println("********in allocatePlaneMethod****"+hangarStatusModel);
		
		hangarService.allocatePlane(hangarStatusModel);
		List<Number> planeIdList =planeService.getAllPlaneId();
		mv.addObject("planeIdList",planeIdList);
		mv.addObject("status",status);
		mv.setViewName("hangarAllocationForm");
		return mv;
	}
	@RequestMapping(value="viewHangarStatus.htm",method=RequestMethod.GET)
	public ModelAndView viewHangarStatus()
	{
		logger.info("View All Hangar Status");
		List<HangarStatus> hangarStatusList = hangarService.getAllHangarStatus();
		ModelAndView mv = new ModelAndView();
		mv.addObject("hangarStatusList", hangarStatusList);
		mv.setViewName("viewHangarStatus");
		return mv;
	}
	

	@ModelAttribute("hangarStatusModel")
	public HangarStatusModel createCommandObject1() {
		HangarStatusModel hangarStatusModel = new HangarStatusModel();
		return hangarStatusModel;
	}

	@ModelAttribute("hangarModel")
	public HangarModel createCommandObject() {
		HangarModel hangarModel = new HangarModel();
		return hangarModel;
	}

}