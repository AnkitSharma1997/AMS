package com.cognizant.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.model.ManagerModel;
import com.cognizant.service.ManagerService;

@Controller
public class ManagerController {

	@Autowired
	private ManagerService managerService;

	@Autowired
	@Qualifier("managerLoginValidator")
	private Validator loginValidator;
	
	@Autowired
	@Qualifier("managerRegistrationValidator")
	private Validator registerValidator;
	
	private static final Logger logger = LoggerFactory.getLogger(ManagerController.class);
		
	@RequestMapping("managerRegister")
	public String viewManagerReg(){
		logger.info("Loading Manager Registration Page");
		return "managerRegister";
	}
	
	@RequestMapping("managerRegisterSuccess.htm")
	public ModelAndView viewRegistrationPage(@ModelAttribute("managerModel") ManagerModel managerModel,Errors errors){
		ModelAndView mv = new ModelAndView();	
		logger.info("Manager Registration Page Submitted");

		ValidationUtils.invokeValidator(registerValidator, managerModel , errors);
		if(errors.hasErrors())
		{
			logger.info("Manager Registration Failed");
			mv.setViewName("managerRegister");
		}
		else
		{
		boolean persistManager=managerService.managerRegister(managerModel);
		if(persistManager)
		{
			logger.info("Manager Registration Successfully");
			String Id=managerService.getId();
			mv.addObject("status","Manager Registered");
			mv.addObject("managerMSG", managerModel.getManagerFirstName()+managerModel.getManagerLastName()+" can Login using =>");
			mv.addObject("note", "Manager Id : ");
			mv.addObject("managerId", Id);
		}
		else{
			logger.info("Manager Registration Failed");
			mv.addObject("status","Manager Registration Failed");
		}
		}
		mv.setViewName("managerRegister");
		return mv;
	}
	
	@RequestMapping("managerLogin.htm")
	public String viewManagerlogin(){
		logger.info("Loading Manager Login Page");
		return "managerLogin";
	}

	@RequestMapping(value="managerLoginSuccess.htm",method=RequestMethod.POST)
	public ModelAndView managerLogin(@ModelAttribute("managerModel") ManagerModel managerModel,Errors errors,HttpSession session)
	{
		logger.info("Manager Login Page Submitted");
		ModelAndView mv=new ModelAndView();
		ValidationUtils.invokeValidator(loginValidator, managerModel , errors);
		if(errors.hasErrors())
		{
			logger.info("Manager Login Failed");
			mv.setViewName("managerLogin");
		}
		else 
		{
		int managerExists=managerService.checkCredentilas(managerModel);
		if(managerExists==4)
		{	
			logger.info("Manager Login Successful");
			mv.addObject("status","Manager Login Successful");
			mv.addObject("managerId", managerModel.getManagerId());
			mv.addObject("managerName", managerModel.getManagerFirstName());
			session.setAttribute("managerId",managerModel.getManagerId());
			session.setAttribute("managerName",managerModel.getManagerFirstName());
			mv.setViewName("welcomeManager");
			}
		else if(managerExists==5){
			logger.info("Manager Pending");
			mv.addObject("status","Manager Pending");
			mv.setViewName("managerLogin");
		}
		else if(managerExists==6){
			logger.info("Manager Rejected");
			mv.addObject("status","Manager Rejected");
			mv.setViewName("managerLogin");
		}
		}
		return mv;		
	}

	@RequestMapping(value="managerLogout.htm",method=RequestMethod.GET)
	public ModelAndView logout (HttpSession session){
		ModelAndView mv = new ModelAndView();
		session.invalidate();
		logger.info("Manager Logout Successful");
		mv.setViewName("main");
		return mv;
	}
	
	@RequestMapping(value="welcomeManager.htm")
	public String loadAdminWelcome(){
		logger.info("Loading Manager Welcome Page");
		return "welcomeManager";
	}
	
	@ModelAttribute("managerModel")
	public ManagerModel managerObject(){
		ManagerModel  managerModel = new ManagerModel();
		return managerModel;
	}
	
	@ModelAttribute("genderList")
	public List<String> createGenderList(){
		return managerService.getGender();
	}
}
