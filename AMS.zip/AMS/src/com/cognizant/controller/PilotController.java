package com.cognizant.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Pilot;
import com.cognizant.model.PilotModel;
import com.cognizant.service.PilotService;

@Controller
@SessionAttributes("view1PilotModel")
public class PilotController {

	@Autowired
	private PilotService pilotService;

	@Autowired
	@Qualifier("pilotValidator")
	private Validator validator;
	
	private static final Logger logger = LoggerFactory.getLogger(PilotController.class);
			
	@RequestMapping(value="pilotMain.htm",method=RequestMethod.GET)
	public String loadPilotMain(){
		logger.info("Loading Pilot Main Page");
		return "pilotMain";
	}
	
	@RequestMapping(value="pilotForm.htm",method=RequestMethod.GET)
	public String loadPilotForm(){
		logger.info("Loading Add Pilot Form");
		return "pilotForm";
	}

	@RequestMapping(value="addPilot.htm",method=RequestMethod.POST)
	public ModelAndView persistPilot(@ModelAttribute("pilotModel")PilotModel pilotModel,Errors errors){
		
		ModelAndView mv=new ModelAndView();
		logger.info("Add Pilot Form Submitted");

		ValidationUtils.invokeValidator(validator, pilotModel , errors);
		if(errors.hasErrors())
		{
			logger.info("Addition of Pilot Failed");
			mv.setViewName("pilotForm");
		}
		else
		{
			boolean pilotPersist=pilotService.persistPilot(pilotModel);
			if(pilotPersist)
			{
				logger.info("Addition of Pilot Successful");
				mv.addObject("status", "Your details are submitted successfully");
			}
			else
			{
				logger.info("Addition of Pilot Failed");
				mv.addObject("status", "Please update the highlighted mandatory field(s)");			
			}
		}
		mv.setViewName("pilotForm");		
		return mv;
	}
	
	@RequestMapping(value = "viewPilots.htm", method = RequestMethod.GET)
	public ModelAndView viewPilots() {
		logger.info("View All Pilots");		
		List<Pilot> pilotList = pilotService.getAllPilots();
		ModelAndView mv = new ModelAndView();
		mv.addObject("pilotList", pilotList);
		mv.setViewName("viewPilots");
		return mv;
	}

	@RequestMapping(value="viewOnePilot.htm",method=RequestMethod.GET)
	public ModelAndView viewPilot(ModelMap map,@ModelAttribute("pilotmodel") PilotModel pilotModel,@RequestParam("pilotId")int pilot1)
	{	
		logger.info("View One Pilot Details");
		ModelAndView mv=new ModelAndView();	
		PilotModel view1PilotModel = pilotService.getPilot(pilot1);		
		map.addAttribute("view1PilotModel",view1PilotModel);
		mv.setViewName("viewOnePilot");
		return mv;
	}

	@RequestMapping(value="editPilot.htm",method=RequestMethod.POST)
	public ModelAndView updatePilot(@ModelAttribute("view1PilotModel")PilotModel pilotModel,Errors errors){
		logger.info("Update Pilot Form Submitted");

		ModelAndView mv=new ModelAndView();
		ValidationUtils.invokeValidator(validator, pilotModel , errors);
		if(errors.hasErrors())
		{
			logger.info("Updation of Pilot Failed");
			mv.setViewName("pilotForm");
		}
		else
		{
			boolean pilotUpdate=pilotService.updatePilot(pilotModel);
			if(pilotUpdate)
			{
				logger.info("Updation of Pilot Successful");
				mv.addObject("status", "Your details are submitted successfully");
			}
			else
			{
				logger.info("Updation of Pilot Failed");
				mv.addObject("status", "Pilot registration failed, TRY Again");			
			}
		}
			mv.setViewName("viewOnePilot");		
		return mv;
	}

	@ModelAttribute("pilotModel")                            
	public PilotModel createCommandObject(){                 
		PilotModel pilotModel=new PilotModel();                      
		return pilotModel;
	}

}