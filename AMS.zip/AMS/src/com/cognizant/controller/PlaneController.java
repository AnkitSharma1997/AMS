package com.cognizant.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Plane;
import com.cognizant.model.PlaneModel;
import com.cognizant.service.PlaneService;

@Controller
@SessionAttributes("view1PlaneModel")
public class PlaneController {

	@Autowired
	private PlaneService planeService;

	@Autowired
	@Qualifier("planeValidator")
	private Validator validator;
	
	private static final Logger logger = LoggerFactory.getLogger(PlaneController.class);
			
	@RequestMapping(value="planeMain.htm",method=RequestMethod.GET)
	public String loadPlaneMain(){
		logger.info("Loading Plane Main Page");
		return "planeMain";
	}
	
	@RequestMapping(value="planeForm.htm",method=RequestMethod.GET)
	public String loadPlaneForm(){
		logger.info("Loading Add Plane Form");
		return "planeForm";
	}

	@RequestMapping(value="addPlane.htm",method=RequestMethod.POST)
	public ModelAndView persistPlane(@ModelAttribute("planeModel")PlaneModel planeModel,Errors errors){
		
		ModelAndView mv=new ModelAndView();
		logger.info("Add Plane Form Submitted");

		ValidationUtils.invokeValidator(validator, planeModel , errors);
		if(errors.hasErrors())
		{
			logger.info("Addition of Plane Failed");
			mv.setViewName("planeForm");
		}
		else
		{
			boolean planePersist=planeService.persistPlane(planeModel);
			if(planePersist)
			{
				logger.info("Addition of Plane Successful");
				mv.addObject("status", "Your details are submitted successfully");
			}
			else
			{
				logger.info("Addition of Plane Failed");
				mv.addObject("status", "Please update the highlighted mandatory field(s)");			
			}
		}
		mv.setViewName("planeForm");		
		return mv;
	}
	
	@RequestMapping(value = "viewPlanes.htm", method = RequestMethod.GET)
	public ModelAndView viewPlanes() {
		logger.info("View All Planes");		
		List<Plane> planeList = planeService.getAllPlanes();
		ModelAndView mv = new ModelAndView();
		mv.addObject("planeList", planeList);
		mv.setViewName("viewPlanes");
		return mv;
	}

	@RequestMapping(value="viewOnePlane.htm",method=RequestMethod.GET)
	public ModelAndView viewPlane(ModelMap map,@ModelAttribute("planemodel") PlaneModel planeModel,@RequestParam("planeId")int plane1)
	{	
		logger.info("View One Plane Details");
		ModelAndView mv=new ModelAndView();	
		PlaneModel view1PlaneModel = planeService.getPlane(plane1);		
		map.addAttribute("view1PlaneModel",view1PlaneModel);
		mv.setViewName("viewOnePlane");
		return mv;
	}

	@RequestMapping(value="editPlane.htm",method=RequestMethod.POST)
	public ModelAndView updatePlane(@ModelAttribute("view1PlaneModel")PlaneModel planeModel,Errors errors){
		logger.info("Update Plane Form Submitted");

		ModelAndView mv=new ModelAndView();
		ValidationUtils.invokeValidator(validator, planeModel , errors);
		if(errors.hasErrors())
		{
			logger.info("Updation of Plane Failed");
			mv.setViewName("planeForm");
		}
		else
		{
			boolean planeUpdate=planeService.updatePlane(planeModel);
			if(planeUpdate)
			{
				logger.info("Updation of Plane Successful");
				mv.addObject("status", "Your details are submitted successfully");
			}
			else
			{
				logger.info("Updation of Plane Failed");
				mv.addObject("status", "Plane registration failed, TRY Again");			
			}
		}
			mv.setViewName("viewOnePlane");		
		return mv;
	}

	@ModelAttribute("planeModel")                            
	public PlaneModel createCommandObject(){                 
		PlaneModel planeModel=new PlaneModel();                      
		return planeModel;
	}

}