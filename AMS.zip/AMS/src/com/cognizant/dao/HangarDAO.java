package com.cognizant.dao;

import java.util.List;

import com.cognizant.entity.Hangar;
import com.cognizant.entity.HangarStatus;
import com.cognizant.model.HangarStatusModel;

public interface HangarDAO {

	List<Hangar> getAllHangars();
    Hangar getHangar(int hangar1);
	boolean insertHangar(Hangar hangar);	
	boolean updateHangar(Hangar hangar);

	List<HangarStatus> getAllHangarStatus();
	public boolean allocatePlane(HangarStatus hangerStatus);
		
	HangarStatusModel getHangerIdManagerId();
	boolean persistHangarStatus(HangarStatus hangarStatus);
	
}
