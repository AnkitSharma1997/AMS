package com.cognizant.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Hangar;
import com.cognizant.entity.HangarStatus;
import com.cognizant.model.HangarStatusModel;

@Repository("HangarDAOImpl")
public class HangarDAOImpl implements HangarDAO
{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<Hangar> getAllHangars() {

		Session session=sessionFactory.openSession();
		List<Hangar> hangarList=session.createQuery("from Hangar").list();
		session.close();
		return hangarList;
	}

	@Override
	public boolean insertHangar(Hangar hangar) {
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.persist(hangar);
		tx.commit();
		session.close();
		return true;
	}

	@Override
	public Hangar getHangar(int hangar1) {
		
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Hangar o where o.hangarId=:hangarId");
		query.setInteger("hangarId", hangar1);

		Hangar hangar=(Hangar)query.uniqueResult();
		session.close();
		
		return hangar;

	}

	@Override
	public boolean updateHangar(Hangar hangar) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.merge(hangar);
		tx.commit();
		session.close();
		return true;
	}

	@Override
	public List<HangarStatus> getAllHangarStatus() {

		Session session=sessionFactory.openSession();
		List<HangarStatus> hangarStatusList=session.createQuery("from HangarStatus").list();
		session.close();
		return hangarStatusList;
	}

	@Override
	public boolean allocatePlane(HangarStatus hangarStatus) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.merge(hangarStatus);		
		transaction.commit();
		session.close();
		return true;
	}

	@Override
	public HangarStatusModel getHangerIdManagerId() {
		// TODO Auto-generated method stub
		Number hangarId=0;
		String managerId="";
		
		int hangarId1=0;
		Session session = sessionFactory.openSession();
		SQLQuery query1 = session.createSQLQuery("select hangar_id from hangar");
		SQLQuery query2 = session.createSQLQuery("select manager_id from hangar");
		
		List<Number> hangarIdValue = query1.list();
		List<String> managerIdValue = query2.list();
		hangarId = hangarIdValue.get(hangarIdValue.size() - 1);
		managerId = managerIdValue.get(managerIdValue.size() -1);

		//System.out.println("################## "+ hangarId +"################");

		hangarId1=hangarId.intValue();
		HangarStatusModel hangarStatusModel = new  HangarStatusModel();
		
		hangarStatusModel.setHangarId(hangarId1);
		hangarStatusModel.setManagerId(managerId);
		
		return hangarStatusModel;
	}

	@Override
	public boolean persistHangarStatus(HangarStatus hangarStatus) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.persist(hangarStatus);
		tx.commit();
		session.close();
		return true;
	}
	
	
	
	
}
