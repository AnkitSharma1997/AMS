package com.cognizant.dao;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Manager;
import com.cognizant.entity.Manager;
import com.cognizant.entity.Manager;

@Repository("ManagerDAOImpl")
public class ManagerDAOImpl implements ManagerDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	static String id;

	@Override
	public boolean managerRegister(Manager manager){		
		Session session = sessionFactory.openSession();
		generateManagerId();
		Transaction tx = session.beginTransaction();	
		tx.begin();
		session.persist(manager);
		tx.commit();
		id=manager.getManagerId();
		session.close();
		return true;
	}

	@Override
	public String getId(){
		return id;
	}

	@Override
	public int checkEmailAndContactNo(Manager manager) {
		
		Session session=sessionFactory.openSession();
		int dataExists = 0;
		
		Query query=session.createQuery("select o from Manager o where o.managerEmailId=:managerEmailId and o.managerContactNo=:managerContactNo");
		query.setParameter("managerEmailId", manager.getManagerEmailId());
		query.setParameter("managerContactNo", manager.getManagerContactNo());
		List<Manager> managerList=query.list();

		String str1 =" from Manager as o where o.managerEmailId=?";
		Query query1 = session.createQuery(str1);
		query1.setParameter(0,manager.getManagerEmailId());
		List list1 = query1.list();
		
		String str2 =" from Manager as o where o.managerContactNo=?";
		Query query2 = session.createQuery(str2);
		query2.setParameter(0,manager.getManagerContactNo());
		List list2 = query2.list();
		
		if ((managerList != null) && (managerList.size() > 0)) {
			dataExists= 3;   //both exists
		}

		if (!(list1.isEmpty())) {
			dataExists= 1;//email exists
		}

		if (!(list2.isEmpty())) {
			dataExists= 2;//contact no exists
		}
		
		session.close();
		return dataExists;              
   }

	@Override
	public int managerCredentials(Manager manager) {
		Session session=sessionFactory.openSession();

		Manager manager1=(Manager)session.get(Manager.class,manager.getManagerId());
		
		if(manager1 != null)
		{
			if(manager1.getManagerPassword().equals(manager.getManagerPassword()))
			{
				if(manager1.getManagerStatus().equals("Approved"))
				return 4;
				
				if(manager1.getManagerStatus().equals("Pending"))
				return 5;
				
				if(manager1.getManagerStatus().equals("Rejected"))
				return 6;							
			}
			else return 2;
		}
		return 1;
	}
	
	@Override
	public void generateManagerId() {
		
		Session session=sessionFactory.openSession();
		Query query=session.createSQLQuery("select MANAGERIDSEQ.nextval FROM DUAL");
		Long key=((BigDecimal)query.uniqueResult()).longValue();
		System.out.println("Id generated:"+key);
		ManagerStoreId.addId(key.intValue());
	}
	
	@Override
	public List<String> getGender() {

		Session session=sessionFactory.openSession();
		Query query=session.createSQLQuery("select gender_option from gender");
		List<String> genderList=query.list();
			
			return genderList;
	}
}
