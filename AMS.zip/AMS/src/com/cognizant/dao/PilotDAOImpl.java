package com.cognizant.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Pilot;
import com.cognizant.model.PilotModel;

@Repository("PilotDAOImpl")
public class PilotDAOImpl implements PilotDAO
{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<Pilot> getAllPilots() {

		Session session=sessionFactory.openSession();
		List<Pilot> pilotList=session.createQuery("from Pilot").list();
		session.close();
		return pilotList;
	}

	@Override
	public boolean insertPilot(Pilot pilot) {
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.persist(pilot);
		tx.commit();
		session.close();
		return true;
	}

	@Override
	public Pilot getPilot(int pilot1) {
		
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Pilot o where o.pilotId=:pilotId");
		query.setInteger("pilotId", pilot1);
		Pilot pilot=(Pilot)query.uniqueResult();
		session.close();
		
		return pilot;

	}

	@Override
	public boolean updatePilot(Pilot pilot) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.merge(pilot);
		tx.commit();
		session.close();
		return true;
	}
	
}
