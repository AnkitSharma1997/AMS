package com.cognizant.dao;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Plane;
import com.cognizant.model.PlaneModel;

@Repository("PlaneDAOImpl")
public class PlaneDAOImpl implements PlaneDAO
{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<Plane> getAllPlanes() {

		Session session=sessionFactory.openSession();
		List<Plane> planeList=session.createQuery("from Plane").list();
		session.close();
		return planeList;
	}

	@Override
	public boolean insertPlane(Plane plane) {
		//generatePlaneId();
	Session session=sessionFactory.openSession();
		
		Transaction tx=session.beginTransaction();
		session.persist(plane);
		tx.commit();
		session.close();
		return true;
	}

	@Override
	public Plane getPlane(int plane1) {		
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Plane o where o.planeId=:planeId");
		query.setInteger("planeId", plane1);
		Plane plane=(Plane)query.uniqueResult();
		session.close();		
		return plane;
	}

	@Override
	public boolean updatePlane(Plane plane) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.merge(plane);
		tx.commit();
		session.close();
		return true;
	}

	@Override
	public List<Number> getAllPlaneId()
	{		
		Session session = sessionFactory.openSession();		
	    SQLQuery query = session.createSQLQuery("SELECT distinct p.plane_id FROM planes p WHERE p.plane_id Not IN (SELECT hs.plane_id FROM HANGAR_STATUS hs)");
		List<Number> planeIdList = query.list();
		
		//System.out.println("######%%%%%%"+ planeIdList+"%%%%%%%%######");
		
		return planeIdList;
	}

}
