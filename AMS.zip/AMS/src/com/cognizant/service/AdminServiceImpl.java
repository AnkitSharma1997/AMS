package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDAO;
import com.cognizant.entity.Admin;
import com.cognizant.entity.Manager;
import com.cognizant.model.AdminModel;

@Service("AdminServiceImpl")
public class AdminServiceImpl implements AdminService {

	@Autowired
	@Qualifier("AdminDAOImpl")
	private AdminDAO adminDAO;
	
	@Override
	public boolean registerAdmin(AdminModel adminModel) {

		Admin admin=new Admin();
		
	//	admin.setAdminId(adminModel.getAdminId());
		admin.setAdminFirstName(adminModel.getAdminFirstName());
		admin.setAdminLastName(adminModel.getAdminLastName());
		admin.setAdminAge(adminModel.getAdminAge());
		admin.setAdminGender(adminModel.getAdminGender());
		admin.setAdminDob(adminModel.getAdminDob());
		admin.setAdminContactNo(adminModel.getAdminContactNo());
		admin.setAdminAltContactNo(adminModel.getAdminAltContactNo());
		admin.setAdminEmailId(adminModel.getAdminEmailId());
		admin.setAdminPassword(adminModel.getAdminPassword());
		
		return adminDAO.registerAdmin(admin);
	}

	@Override
	public int checkEmailAndContactNo(AdminModel adminModel) {

		Admin admin=new Admin();
		
		admin.setAdminFirstName(adminModel.getAdminFirstName());
		admin.setAdminLastName(adminModel.getAdminLastName());
		admin.setAdminAge(adminModel.getAdminAge());
		admin.setAdminGender(adminModel.getAdminGender());
		admin.setAdminDob(adminModel.getAdminDob());
		admin.setAdminContactNo(adminModel.getAdminContactNo());
		admin.setAdminAltContactNo(adminModel.getAdminAltContactNo());
		admin.setAdminEmailId(adminModel.getAdminEmailId());
		admin.setAdminPassword(adminModel.getAdminPassword());
		
		return adminDAO.checkEmailAndContactNo(admin);
	}

	@Override
	public String getId() {
		return adminDAO.getId();
	}

	@Override
	public int checkAdminLogin(AdminModel adminModel)
	{
		Admin admin=new Admin();
		
		admin.setAdminId(adminModel.getAdminId());
		admin.setAdminFirstName(adminModel.getAdminFirstName());
		admin.setAdminLastName(adminModel.getAdminLastName());
		admin.setAdminAge(adminModel.getAdminAge());
		admin.setAdminGender(adminModel.getAdminGender());
		admin.setAdminDob(adminModel.getAdminDob());
		admin.setAdminContactNo(adminModel.getAdminContactNo());
		admin.setAdminAltContactNo(adminModel.getAdminAltContactNo());
		admin.setAdminEmailId(adminModel.getAdminEmailId());
		admin.setAdminPassword(adminModel.getAdminPassword());

		return adminDAO.checkAdminLogin(admin);
		
	}

	@Override
	public List<String> getGender() {
		return adminDAO.getGender();
	}
	
	@Override
	public List<Manager> getAllPendingRequests() {
		// TODO Auto-generated method stub
		//System.out.println("service");
		
		return adminDAO.getAllPendingRequests();
	}
	
	@Override
	public boolean approveManagerRequest(String managerId) {
		return adminDAO.approveManagerRequest( managerId);		
	}

	@Override
	public boolean rejectManagerRequest(String managerId) {
		return adminDAO.rejectManagerRequest( managerId);
	}

}