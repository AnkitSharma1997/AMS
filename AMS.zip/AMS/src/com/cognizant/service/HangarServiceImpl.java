package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cognizant.dao.HangarDAO;
import com.cognizant.entity.Hangar;
import com.cognizant.entity.HangarStatus;
import com.cognizant.model.HangarModel;
import com.cognizant.model.HangarStatusModel;

@Service("HangarServiceImpl")
public class HangarServiceImpl implements HangarService {
	// used to forming computation

	@Autowired
	@Qualifier("HangarDAOImpl")
	private HangarDAO hangarDAO;

	@Override
	public List<Hangar> getAllHangars() {
		return hangarDAO.getAllHangars();
	}

	@Override
	public boolean persistHangar(HangarModel hangarModel) {

		Hangar hangar=new Hangar();
		
		//hangar.setHangarId(hangarModel.getHangarId());
		hangar.setManagerId(hangarModel.getManagerId());
		hangar.setManagerAddressLine1(hangarModel.getManagerAddressLine1());
		hangar.setManagerAddressLine2(hangarModel.getManagerAddressLine2());
		hangar.setHangarCity(hangarModel.getHangarCity());
		hangar.setHangarState(hangarModel.getHangarState());
		hangar.setHangarZipCode(hangarModel.getHangarZipCode());
		
		return hangarDAO.insertHangar(hangar);
	}

	@Override
	public HangarModel getHangar(int hangar1) {

	Hangar hangar= hangarDAO.getHangar(hangar1);
	HangarModel hangarModel=new HangarModel();
		
	hangarModel.setHangarId(hangar.getHangarId());
	hangarModel.setManagerId(hangar.getManagerId());
	hangarModel.setManagerAddressLine1(hangar.getManagerAddressLine1());
	hangarModel.setManagerAddressLine2(hangar.getManagerAddressLine2());
	hangarModel.setHangarCity(hangar.getHangarCity());
	hangarModel.setHangarState(hangar.getHangarState());
	hangarModel.setHangarZipCode(hangar.getHangarZipCode());

	return hangarModel;

	}

	@Override
	public boolean updateHangar(HangarModel hangarModel) {

		Hangar hangar=new Hangar();
		
		hangar.setHangarId(hangarModel.getHangarId());
		hangar.setManagerId(hangarModel.getManagerId());
		hangar.setManagerAddressLine1(hangarModel.getManagerAddressLine1());
		hangar.setManagerAddressLine2(hangarModel.getManagerAddressLine2());
		hangar.setHangarCity(hangarModel.getHangarCity());
		hangar.setHangarState(hangarModel.getHangarState());
		hangar.setHangarZipCode(hangarModel.getHangarZipCode());
		
		return hangarDAO.updateHangar(hangar);

	}

	@Override
	public List<HangarStatus> getAllHangarStatus() {
		return hangarDAO.getAllHangarStatus();
	}

	@Override
	public boolean allocatePlane(HangarStatusModel hangerStatusModel) {
			
		System.out.println("in service impl"+hangerStatusModel.getPlaneId());
		
		HangarStatus hangarStatus = new HangarStatus();
		
		hangarStatus.setPlaneId(hangerStatusModel.getPlaneId());		
		hangarStatus.setOccupancyFromDate(hangerStatusModel.getOccupancyFromDate());
		hangarStatus.setOccupancyTillDate(hangerStatusModel.getOccupancyTillDate());
		hangarStatus.setAvailableFromDate(hangerStatusModel.getAvailableFromDate());
		hangarStatus.setAvailableFromDate(hangerStatusModel.getAvailableFromDate());
		hangarStatus.setStatus("O");
		hangarStatus.setHangarId(hangerStatusModel.getHangarId());
		hangarStatus.setManagerId(hangerStatusModel.getManagerId());
			
			return hangarDAO.allocatePlane(hangarStatus);
	}

	@Override
	public HangarStatusModel getHangarIdManagerId() {
		// TODO Auto-generated method stub
		HangarStatusModel hangarStatusModel = hangarDAO.getHangerIdManagerId(); 
		HangarStatus hangarStatus = new HangarStatus();
		hangarStatusModel.setAvailableFromDate("0");
		hangarStatusModel.setAvailableTillDate("0");
		hangarStatusModel.setOccupancyFromDate("0");
		hangarStatusModel.setOccupancyTillDate("0");
		hangarStatusModel.setStatus("A");
		
		hangarStatus.setAvailableFromDate(hangarStatusModel.getAvailableFromDate());
		hangarStatus.setAvailableTillDate(hangarStatusModel.getAvailableTillDate());
		hangarStatus.setHangarId(hangarStatusModel.getHangarId());
		hangarStatus.setManagerId(hangarStatusModel.getManagerId());
		hangarStatus.setOccupancyFromDate(hangarStatusModel.getOccupancyFromDate());
		hangarStatus.setOccupancyTillDate(hangarStatusModel.getOccupancyTillDate());
		hangarStatus.setPlaneId(hangarStatusModel.getPlaneId());
		hangarStatus.setStatus(hangarStatusModel.getStatus());
		
		
		hangarDAO.persistHangarStatus(hangarStatus);
		return hangarStatusModel;
	}
	
	
}
