package com.cognizant.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.cognizant.dao.ManagerDAO;
import com.cognizant.entity.Manager;
import com.cognizant.model.ManagerModel;

@Service("ManagerServiceImpl")
public class ManagerServiceImpl  implements ManagerService {

	@Autowired
	@Qualifier("ManagerDAOImpl")
	private ManagerDAO managerDAO;
	
	private boolean flag;
	
	@Override
	public boolean managerRegister(ManagerModel managerModel){

		Manager manager = new Manager();
		 
	//	 manager.setManagerId(managerModel.getManagerId());
		 manager.setManagerFirstName(managerModel.getManagerFirstName());
		 manager.setManagerLastName(managerModel.getManagerLastName());
		 manager.setManagerAge(managerModel.getManagerAge());
		 manager.setManagerGender(managerModel.getManagerGender());
		 manager.setManagerContactNo(managerModel.getManagerContactNo());
		 manager.setManagerAltContactNo(managerModel.getManagerAltContactNo());
		 manager.setManagerDob(managerModel.getManagerDob());
		 manager.setManagerEmailId(managerModel.getManagerEmailId());
		 manager.setManagerPassword(managerModel.getManagerPassword());
		 manager.setManagerStatus("Pending");
		 
		 return managerDAO.managerRegister(manager);
	}
	
	@Override
	public int checkEmailAndContactNo(ManagerModel managerModel) {

		Manager manager=new Manager();
		
		manager.setManagerFirstName(managerModel.getManagerFirstName());
		manager.setManagerLastName(managerModel.getManagerLastName());
		manager.setManagerAge(managerModel.getManagerAge());
		manager.setManagerGender(managerModel.getManagerGender());
		manager.setManagerDob(managerModel.getManagerDob());
		manager.setManagerContactNo(managerModel.getManagerContactNo());
		manager.setManagerAltContactNo(managerModel.getManagerAltContactNo());
		manager.setManagerEmailId(managerModel.getManagerEmailId());
		manager.setManagerPassword(managerModel.getManagerPassword());
		
		return managerDAO.checkEmailAndContactNo(manager);
	}

	@Override
	public String getId() {
		return managerDAO.getId();
	}

	@Override
	public int checkCredentilas(ManagerModel managerModel) {
		
		Manager manager = new Manager();
		 
		 manager.setManagerId(managerModel.getManagerId());
		 manager.setManagerPassword(managerModel.getManagerPassword());
		 
		 return managerDAO.managerCredentials(manager);
	}

	@Override
	public List<String> getGender() {
		return managerDAO.getGender();

	}

}
