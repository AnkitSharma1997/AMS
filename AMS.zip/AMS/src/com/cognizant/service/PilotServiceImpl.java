package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cognizant.dao.PilotDAO;
import com.cognizant.entity.Pilot;
import com.cognizant.model.PilotModel;

@Service("PilotServiceImpl")
public class PilotServiceImpl implements PilotService {
	// used to forming computation

	@Autowired
	@Qualifier("PilotDAOImpl")
	private PilotDAO pilotDAO;

	@Override
	public List<Pilot> getAllPilots() {
		return pilotDAO.getAllPilots();
	}

	@Override
	public boolean persistPilot(PilotModel pilotModel) {

		Pilot pilot=new Pilot();
		
		//pilot.setPilotId(pilotModel.getPilotId());
		pilot.setPilotLicenseNumber(pilotModel.getPilotLicenseNumber());
		pilot.setPilotAddressLine1(pilotModel.getPilotAddressLine1());
		pilot.setPilotAddressLine2(pilotModel.getPilotAddressLine2());
		pilot.setPilotCity(pilotModel.getPilotCity());
		pilot.setPilotState(pilotModel.getPilotState());
		pilot.setPilotZipCode(pilotModel.getPilotZipCode());
		pilot.setPilotSsn(pilotModel.getPilotSsn());
		
		return pilotDAO.insertPilot(pilot);
	}

	@Override
	public PilotModel getPilot(int pilot1) {

	Pilot pilot= pilotDAO.getPilot(pilot1);
	PilotModel pilotModel=new PilotModel();
		
	pilotModel.setPilotId(pilot.getPilotId());
	pilotModel.setPilotLicenseNumber(pilot.getPilotLicenseNumber());
	pilotModel.setPilotAddressLine1(pilot.getPilotAddressLine1());
	pilotModel.setPilotAddressLine2(pilot.getPilotAddressLine2());
	pilotModel.setPilotCity(pilot.getPilotCity());
	pilotModel.setPilotState(pilot.getPilotState());
	pilotModel.setPilotZipCode(pilot.getPilotZipCode());
	pilotModel.setPilotSsn(pilot.getPilotSsn());

	return pilotModel;

	}

	@Override
	public boolean updatePilot(PilotModel pilotModel) {

		Pilot pilot=new Pilot();
		
		pilot.setPilotId(pilotModel.getPilotId());
		pilot.setPilotLicenseNumber(pilotModel.getPilotLicenseNumber());
		pilot.setPilotAddressLine1(pilotModel.getPilotAddressLine1());
		pilot.setPilotAddressLine2(pilotModel.getPilotAddressLine2());
		pilot.setPilotCity(pilotModel.getPilotCity());
		pilot.setPilotState(pilotModel.getPilotState());
		pilot.setPilotZipCode(pilotModel.getPilotZipCode());
		pilot.setPilotSsn(pilotModel.getPilotSsn());
		
		return pilotDAO.updatePilot(pilot);

	}

}
