package com.cognizant.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cognizant.model.AdminModel;
import com.cognizant.service.AdminService;

@Component
public class AdminLoginValidator implements Validator{

	@Autowired
	private AdminService adminService;
	
	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return arg0.equals(AdminModel.class);
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub
		AdminModel adminModel=(AdminModel)arg0;
		
		ValidationUtils.rejectIfEmpty(arg1, "adminId", "adminId.required");
		ValidationUtils.rejectIfEmpty(arg1, "adminPassword", "adminPassword.required");

		if(adminModel.getAdminId()!="" && adminModel.getAdminPassword()!="")
		{	
		int adminAuth=adminService.checkAdminLogin(adminModel);
		if(adminAuth==1)
		{
			arg1.rejectValue("adminId", "com.cognizant.entity.Admin.adminId.invalid");
		}
		else if(adminAuth==2)
		{
			arg1.rejectValue("adminPassword", "com.cognizant.entity.Admin.adminPassword.invalid");
		}
		else if(adminAuth==3)
		{
			arg1.rejectValue("adminId", "com.cognizant.entity.Admin.adminId.invalid");
			arg1.rejectValue("adminPassword", "com.cognizant.entity.Admin.adminPassword.invalid");
		}
		}
	}

}
