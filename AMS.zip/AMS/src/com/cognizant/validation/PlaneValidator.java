package com.cognizant.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cognizant.model.PlaneModel;
import com.cognizant.service.PlaneService;

@Component
public class PlaneValidator implements Validator
{

	@Autowired
	private PlaneService planeService;
	
	@Override
	public boolean supports(Class<?>arg0)
	{
		return arg0.equals(PlaneModel.class);
	}
	
	@Override
	public void validate(Object arg0, Errors arg1)
	{

		PlaneModel planeModel=(PlaneModel)arg0;

		ValidationUtils.rejectIfEmpty(arg1, "ownerFirstName", "ownerFirstName.required");
		ValidationUtils.rejectIfEmpty(arg1, "ownerLastName", "ownerLastName.required");
		ValidationUtils.rejectIfEmpty(arg1, "ownerContactNo", "ownerContactNo.required");
		ValidationUtils.rejectIfEmpty(arg1, "ownerEmail", "ownerEmail.required");
		ValidationUtils.rejectIfEmpty(arg1, "planeType", "planeType.required");
		ValidationUtils.rejectIfEmpty(arg1, "planeCapacity", "planeCapacity.required");
	}
}